<?php

$config = mysqli_connect("localhost", "root", "", "multiuser");

?>
